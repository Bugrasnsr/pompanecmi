/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycasting.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msansar <msansar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/15 02:45:16 by mehaydin          #+#    #+#             */
/*   Updated: 2025/01/14 06:10:57 by msansar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cub3d.h"

void	executeRaycasting(t_c3d *cub3d)
{
	t_raycaster	ray;
	int		x;

	ray.real_position.x = cub3d->game->player->position.x;
	ray.real_position.y = cub3d->game->player->position.y;
	x = 0;
	while (x < SCREEN_WIDTH)
	{
		init_ray_properties(&ray, cub3d->game->player, x);
		draw_ray_until_wall(&ray, cub3d->config->map);
		set_wall_properties_with_ray(&ray, cub3d->game->player);
		set_texture_properties(&ray);
		fill_screen_with_rays(&ray, cub3d->game, x);
		x++;
	}
}
