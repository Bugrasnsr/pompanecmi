/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_free_cub3d.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msansar <msansar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/15 02:39:09 by mehaydin          #+#    #+#             */
/*   Updated: 2025/01/14 06:11:10 by msansar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

t_c3d	*initialize_c3d(int argument_count, char *filename)
{
    t_c3d	*cub3d;

    cub3d = calloc(1, sizeof(t_c3d)); // malloc yerine calloc kullanıldı
    if (cub3d == NULL)
    {
        report_error(cub3d, "cub3d malloc error.");
    }
	configure_cub3d(cub3d, argument_count, filename);
	initialize_xpm_image_files(cub3d);
	initialize_colors(cub3d);
	initialize_map(cub3d);
	cub3d->game = NULL;
	return (cub3d);
}

void	free_cub3d(t_c3d *cub3d)
{
	if (cub3d == NULL)
		return ;
	release_cub3d_config(cub3d);
	free_game(cub3d);
	free(cub3d);
}
