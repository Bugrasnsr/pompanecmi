/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_map.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: msansar <msansar@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/15 02:43:38 by mehaydin          #+#    #+#             */
/*   Updated: 2025/01/14 06:04:38 by msansar          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cub3d.h"

void	validate_map(t_c3d *cub3d)
{
	initialize_map_text(cub3d);
	validate_map_for_empty_lines(cub3d);
	check_map_characters(cub3d);
	validate_map_walls(cub3d);
	validate_map_spaces(cub3d);
}
