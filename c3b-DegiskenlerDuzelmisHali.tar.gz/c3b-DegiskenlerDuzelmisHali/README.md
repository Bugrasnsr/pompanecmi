cub3D Projesi
Proje Hakkında
Bu repo, 42 Okulu'nun cub3D projesi için hazırlanmıştır. Projemiz, 1992'deki klasik FPS oyunu Wolfenstein 3D'den esinlenerek, "ray-casting" tekniğini kullanarak basit bir 3D görünüm oluşturmayı amaçlamaktadır. Bu proje, grafik programlamadaki temel kavramları anlamak ve uygulamak için mükemmel bir fırsattır.

Özellikler
~2D harita dosyasından 3D duvar renderlaması
~Temel FPS hareket kontrolleri: ileri, geri, sola, sağa hareket etme ve dönüme
~Basit bir dokusal renderlama sistemi
